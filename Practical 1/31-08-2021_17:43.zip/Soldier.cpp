#include "Zombie.h"
#include "Soldier.h"
#include <iostream>


Soldier::Soldier(){
	// name = n;
	// hp = h;
	// primaryWeapon = pW;
	// secondaryWeapon = sW;
}

Soldier::~Soldier()
{

}


void Soldier::attack(Zombie* z){
	while(hp > 0 && z->getHP() > 0){
		if (hitZombie(z) == true)
		{
			celebrate();
		}
		else {
			die();
		}
	}
}