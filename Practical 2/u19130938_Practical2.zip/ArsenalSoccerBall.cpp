#include "ArsenalSoccerBall.h"
#include "SoccerBall.h"

#include <iostream>
#include <string>


ArsenalSoccerBall::ArsenalSoccerBall() : SoccerBall("Arsenal", 34, true){

}

ArsenalSoccerBall::ArsenalSoccerBall(bool i, double p) : SoccerBall("Arsenal", p, i){

}


