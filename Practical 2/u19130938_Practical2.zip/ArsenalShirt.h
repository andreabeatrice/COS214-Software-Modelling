#ifndef ARSENALSHIRT_H
#define ARSENALSHIRT_H

#include "Shirt.h"
#include <string>

using namespace std;

class ArsenalShirt :  public Shirt{

public:
	ArsenalShirt();

	ArsenalShirt(char si, double p);

	
};

#endif