#include <string>
#include <iostream>
#include "PlayStyle.h"
#include "DefendPlayStyle.h"

using namespace std;

DefendPlayStyle::DefendPlayStyle(){

}

string DefendPlayStyle::play(){

	return " is defending their team’s half of the field.";
}