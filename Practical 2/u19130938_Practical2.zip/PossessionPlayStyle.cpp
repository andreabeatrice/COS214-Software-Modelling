#include <string>
#include <iostream>
#include "PlayStyle.h"
#include "PossessionPlayStyle.h"

using namespace std;

PossessionPlayStyle::PossessionPlayStyle(){

}

string PossessionPlayStyle::play(){

	return " is helping their team keep possession of the ball by passing it to their teammates.";
}