#include "LiverpoolSoccerBall.h"
#include "SoccerBall.h"

#include <iostream>
#include <string>


LiverpoolSoccerBall::LiverpoolSoccerBall() : SoccerBall("Liverpool", 28, false){

}

LiverpoolSoccerBall::LiverpoolSoccerBall(bool i, double p) : SoccerBall("Liverpool", p, i){

}


