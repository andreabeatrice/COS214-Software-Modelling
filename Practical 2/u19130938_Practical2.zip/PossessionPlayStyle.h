#ifndef POSSESSIONPLAYSTYLE_H
#define POSSESSIONPLAYSTYLE_H

#include <string>
#include "PlayStyle.h"

using namespace std;

class PossessionPlayStyle : PlayStyle{

public:
	PossessionPlayStyle();
	string play();

};

#endif