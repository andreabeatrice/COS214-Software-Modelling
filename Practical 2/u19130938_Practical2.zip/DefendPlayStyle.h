#ifndef DEFENDPLAYSTYLE_H
#define DEFENDPLAYSTYLE_H

#include <string>
#include "PlayStyle.h"

using namespace std;

class DefendPlayStyle : PlayStyle{

public:
	DefendPlayStyle();
	string play();

};

#endif