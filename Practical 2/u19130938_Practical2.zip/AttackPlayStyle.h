#ifndef ATTACKPLAYSTYLE_H
#define ATTACKPLAYSTYLE_H

#include <string>
#include "PlayStyle.h"

using namespace std;

class AttackPlayStyle : PlayStyle{

public:
	AttackPlayStyle();
	string play();

};

#endif