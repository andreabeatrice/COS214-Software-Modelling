#include <string>
#include <iostream>
#include "PlayStyle.h"
#include "AttackPlayStyle.h"

using namespace std;

AttackPlayStyle::AttackPlayStyle(){

}

string AttackPlayStyle::play(){

	return " is attacking the opposition’s goal with the ball.";
}