#ifndef LIVERPOOLSHIRT_H
#define LIVERPOOLSHIRT_H

#include "Shirt.h"
#include <string>

using namespace std;

class LiverpoolShirt :  public Shirt{

public:
	LiverpoolShirt();

	LiverpoolShirt(char si, double p);

	
};

#endif