#ifndef CHELSEASHIRT_H
#define CHELSEASHIRT_H

#include "Shirt.h"
#include <string>

using namespace std;

class ChelseaShirt :  public Shirt{

public:
	ChelseaShirt();

	ChelseaShirt(char si, double p);

	
};

#endif