#include "Observer.h"
#include "Track.h"
#include "FlagObserver.h"
#include <iostream>
#include <string>
#include <vector>


FlagObserver::FlagObserver(Track* t){
	raceTrack = t;
	waving =false;
}

void FlagObserver::print(){

}

void FlagObserver::update(){


}
